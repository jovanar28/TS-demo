package com.example.demo.vezbe10.cetvrtak;

import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import com.example.demo.persistence.mapper.CountryServiceMapper;
import com.example.demo.persistence.repository.CountryRepository;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DirtiesContext
@TestMethodOrder(MethodOrderer.Random.class)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class CountryTest {

    @Autowired
    private CountryService service;

    @Autowired
    private CountryRepository repository;

    @Autowired
    private CountryServiceMapper mapper;

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void findByIdTest(){
        Country country = service.getCountryById("SRB");

        assertAll(()->assertEquals("SRB",country.getIso3()),
                ()->assertEquals("Serbia",country.getName()));
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void findByIdTest1(){
        assertThrows(NoSuchElementException.class, ()->service.getCountryById("XXX"));
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void findByIdTest2(){
        assertThrows(InvalidDataAccessApiUsageException.class, ()->service.getCountryById(null));
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    void deleteByIdTest(){
        service.deleteCountry("SRB");
        assertThrows(NoSuchElementException.class, ()->repository.findById("SRB").orElseThrow());
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryDelete.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest1(){
        service.deleteCountry("SRB");
    }

    @Disabled
    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest2(){
        assertThrows(NoSuchElementException.class, ()->service.deleteCountry("SRB"));

    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest3(){
        assertThrows(InvalidDataAccessApiUsageException.class, ()->service.deleteCountry(null));
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryEmpty.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteAllTest(){
        service.deleteAll();
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    void createTest(){
        Country country = new Country("MNE","Montenegro");

        service.createCountry(country);

        country = mapper.map(repository.findById("MNE").orElseThrow());

        Country finalCountry = country;
        assertAll(()->assertEquals("MNE", finalCountry.getIso3()),
                ()->assertEquals("Montenegro",finalCountry.getName()));

    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryCreate.xml",
    assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void createTest1(){
        Country country = new Country("MNE","Montenegro");
        service.createCountry(country);
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/countryUpdate.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void updateTest(){
        Country country = new Country("MNE","Montenegro");
        service.updateCountry(country,"SRB");
    }


    @Test
    @DatabaseSetup("classpath:cetvrtak/countryData.xml")
    void updateTest2(){
        Country country = new Country("MNE","Montenegro");

        service.updateCountry(country, "SRB");

        country = mapper.map(repository.findById("SRB").orElseThrow());

        Country finalCountry = country;
        assertEquals("Montenegro",finalCountry.getName());

    }

}
