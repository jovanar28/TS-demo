package com.example.demo.vezbe11.cetvrtak;

import com.example.demo.domen.model.Country;
import com.example.demo.domen.model.Room;
import com.example.demo.domen.model.structure.HotelStructure;
import com.example.demo.domen.service.CountryService;
import com.example.demo.domen.service.RoomService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.NoSuchElementException;
import java.util.stream.Stream;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DirtiesContext
@ExtendWith(MockitoExtension.class)
public class RoomApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RoomService service;

    private static Stream<Arguments> postSource() {
        return Stream.of(
                Arguments.of(getUpdateUrl() + 1L, getRoom(), status().isOk()),
                Arguments.of(getUpdateUrl() + 1L, getRoomMin(), status().isBadRequest()),
                Arguments.of(getUpdateUrl() + 1L, getRoomMin2(), status().isBadRequest()),
                Arguments.of(getUpdateUrl() + 1L, getRoomNoName(), status().isBadRequest()),
                Arguments.of(getUpdateUrl() + 1L, getRoomNull(), status().isBadRequest()),

                Arguments.of(getUpdateUrl() + -1L, getRoom(), status().isBadRequest()),
                Arguments.of(getUpdateUrl() + 0L, getRoom(), status().isNotFound()),



                Arguments.of(getCreateUrl(), getRoom(), status().isOk()),
                Arguments.of(getCreateUrl(), getRoomMin(), status().isBadRequest()),
                Arguments.of(getCreateUrl(), getRoomMin2(), status().isBadRequest()),
                Arguments.of(getCreateUrl(), getRoomNoName(), status().isBadRequest()),
                Arguments.of(getCreateUrl(), getRoomNull(), status().isBadRequest())


                );
    }

    private static String getUrl() {
        return "/api/country/";
    }

    private static String getDeleteUrl() {
        return "/api/country/delete/";
    }

    private static String getCreateUrl() {
        return "/api/room/create/";
    }

    private static String getUpdateUrl() {
        return "/api/room/update/";
    }

    private static Room getRoom() {
        return new Room(1L,"SRB", 2,3,new HotelStructure());
    }

    private static Room getRoomNoName() {
        return new Room(1L,"", 2,3,new HotelStructure());
    }

    private static Room getRoomMin() {
        return new Room(1L,"SRB", 0,3,new HotelStructure());
    }

    private static Room getRoomMin2() {
        return new Room(1L,"SRB", 2,0,new HotelStructure());
    }

    private static Room getRoomNull() {
        return new Room(1L,"SRB", 2,3,null);
    }



    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @ParameterizedTest
    @MethodSource("postSource")
    void testPost(String url, Room room, ResultMatcher matcher) throws Exception {
        when(service.updateRoom(getRoom(), 1L)).thenReturn(getRoom());
        when(service.updateRoom(getRoom(), 0L)).thenThrow(NoSuchElementException.class);
        when(service.updateRoom(getRoom(), -1L)).thenThrow(IllegalArgumentException.class);



        this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(asJsonString(room)))
                .andDo(print()).andExpect(matcher);

    }

}
