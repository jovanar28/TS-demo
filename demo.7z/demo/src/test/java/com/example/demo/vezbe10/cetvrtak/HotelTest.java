package com.example.demo.vezbe10.cetvrtak;


import com.example.demo.domen.model.Hotel;
import com.example.demo.domen.model.structure.CityStructure;
import com.example.demo.domen.model.structure.CountryStructure;
import com.example.demo.domen.service.CityService;
import com.example.demo.domen.service.CountryService;
import com.example.demo.domen.service.HotelService;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.sql.Time;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DirtiesContext
@TestMethodOrder(MethodOrderer.Random.class)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class HotelTest {

    @Autowired
    private HotelService service;
    @Autowired
    private CityService cityService;
    @Autowired
    private CountryService countryService;

    @Test
    @DatabaseSetup("classpath:cetvrtak/hotelData.xml")
    void findById(){

        Hotel hotel = service.getHotelById(1L);

        assertAll(()->assertEquals("name1",hotel.getName()),
                ()-> assertEquals("address1", hotel.getAddress()));

    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/hotelData.xml")
    void findAll(){

        List<Hotel> hotels = service.getHotels();

        assertAll(()->assertEquals(2,hotels.size()));

    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/hotelDelete.xml",
    assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest(){
        service.deleteHotel(2L);
    }


    @Test
    @DatabaseSetup("classpath:cetvrtak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/hotelDeleteALL.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteAllTest(){
        service.deleteAllHotels();
    }

    @Test
    @DatabaseSetup("classpath:cetvrtak/hotelCreate.xml")
    @ExpectedDatabase(value = "classpath:cetvrtak/hotelCreateAfter.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void createTest(){
        Hotel hotel = new Hotel();
        hotel.setContactPhone("+381 22 222 2222");
        hotel.setName("n3");
        hotel.setAddress("a3");
        CountryStructure countryStructure = new CountryStructure("SRB", "Serbia");
        hotel.setCountry(countryStructure);
        hotel.setCity(new CityStructure(1L, "Belgrade", countryStructure));
        hotel.setCheckinTime(Time.valueOf("12:00:00"));
        hotel.setCheckoutTime(Time.valueOf("10:00:00"));
        hotel.setDescription("d3");

        service.createHotel(hotel);

    }
}
