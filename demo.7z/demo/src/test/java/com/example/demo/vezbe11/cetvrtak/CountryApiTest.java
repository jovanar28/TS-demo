package com.example.demo.vezbe11.cetvrtak;

import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.NoSuchElementException;
import java.util.stream.Stream;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DirtiesContext
@ExtendWith(MockitoExtension.class)
public class CountryApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CountryService service;

    private static Stream<Arguments> getSource() {
        return Stream.of(
                Arguments.of(getUrl() + "SRB", status().isOk()),
                Arguments.of(getUrl() + "MNG", status().isNotFound()),
                Arguments.of(getUrl() + " ", status().isBadRequest())
        );
    }

    private static Stream<Arguments> deleteSource() {
        return Stream.of(
                Arguments.of(getDeleteUrl() + "SRB", status().isOk()),
                Arguments.of(getDeleteUrl() + "MNG", status().isNotFound()),
                Arguments.of(getDeleteUrl() + " ", status().isBadRequest())
        );
    }

    private static Stream<Arguments> postSource() {
        return Stream.of(
                Arguments.of(getCreateUrl(), getCountry(), status().isOk()),
                Arguments.of(getCreateUrl(), getCountryNoISO3(), status().isBadRequest()),
                Arguments.of(getCreateUrl(), getCountryNoName(), status().isBadRequest()),
                Arguments.of(getCreateUrl(), null, status().isBadRequest()),

                Arguments.of(getUpdateUrl() + "SRB", getCountry(), status().isOk()),

                Arguments.of(getUpdateUrl() + "MNG", getCountry(), status().isNotFound()),
                Arguments.of(getUpdateUrl() + " ", getCountry(), status().isBadRequest()),

                Arguments.of(getUpdateUrl() + "SRB", getCountryNoName(), status().isBadRequest()),
                Arguments.of(getUpdateUrl() + "SRB", getCountryNoISO3(), status().isBadRequest()),
                Arguments.of(getUpdateUrl() + "SRB", null, status().isBadRequest())

        );
    }

    private static String getUrl() {
        return "/api/country/";
    }

    private static String getDeleteUrl() {
        return "/api/country/delete/";
    }

    private static String getCreateUrl() {
        return "/api/country/create/";
    }

    private static String getUpdateUrl() {
        return "/api/country/update/";
    }

    private static Country getCountry() {
        return new Country("SRB", "Serbia");
    }

    private static Country getCountryNoName() {
        return new Country("SRB", "");
    }

    private static Country getCountryNoISO3() {
        return new Country("", "Serbia");
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void test() throws Exception {
        when(service.getCountryById("SRB")).thenReturn(getCountry());

        this.mockMvc.perform(get(getUrl()+"SRB")).andDo(print()).andExpect(status().isOk());

    }
    @ParameterizedTest
    @MethodSource("getSource")
    void testGet(String url, ResultMatcher matcher) throws Exception {
        //when(service.getCountryById(anyString())).thenThrow(NoSuchElementException.class);

        when(service.getCountryById("SRB")).thenReturn(getCountry());
        when(service.getCountryById("MNG")).thenThrow(NoSuchElementException.class);
        when(service.getCountryById(" ")).thenThrow(IllegalArgumentException.class);


        this.mockMvc.perform(get(url)).andDo(print()).andExpect(matcher);

    }

    @ParameterizedTest
    @MethodSource("deleteSource")
    void testDelete(String url, ResultMatcher matcher) throws Exception {
        //when(service.getCountryById(anyString())).thenThrow(NoSuchElementException.class);
        doThrow(NoSuchElementException.class).when(service).deleteCountry("MNG");

        doThrow(IllegalArgumentException.class).when(service).deleteCountry(" ");


        this.mockMvc.perform(delete(url)).andDo(print()).andExpect(matcher);

    }

    @ParameterizedTest
    @MethodSource("postSource")
    void testDelete(String url, Country country, ResultMatcher matcher) throws Exception {
        when(service.createCountry(getCountry())).thenReturn(getCountry());

        when(service.updateCountry(getCountry(), "MNG")).thenThrow(NoSuchElementException.class);
        when(service.updateCountry(getCountry(), " ")).thenThrow(IllegalArgumentException.class);

        this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(asJsonString(country)))
                .andDo(print()).andExpect(matcher);

    }

}
