package com.example.demo.vezbe10.utorak;


import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DirtiesContext
@TestMethodOrder(MethodOrderer.Random.class)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class CountryTest {

    @Autowired
    private CountryService service;

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    @ExpectedDatabase(value = "classpath:utorak/countryData.xml",
    assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void testFindById(){
        Country country = service.getCountryById("SRB");

        assertAll(()->assertEquals("SRB", country.getIso3()),
                ()->assertEquals("Serbia", country.getName()));
    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    void testDeleteById(){

        service.deleteCountry("SRB");
        assertThrows(RuntimeException.class, ()-> service.getCountryById("SRB"));
    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    @ExpectedDatabase(value = "classpath:utorak/countryDelete.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void testDeleteById1(){

        service.deleteCountry("SRB");

    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    @ExpectedDatabase(value = "classpath:utorak/countryEmpty.xml",
    assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void testDeleteByAll(){

        service.deleteAll();
    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    void updateTest(){
        Country country = new Country();
        country.setIso3("SRB");
        country.setName("Update");
        service.updateCountry(country,"SRB");

        assertEquals("Update", service.getCountryById("SRB").getName());

    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    @ExpectedDatabase(value = "classpath:utorak/countryUpdate.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void updateTest1(){
        Country country = new Country();
        country.setIso3("SRB");
        country.setName("Update");
        service.updateCountry(country,"SRB");
    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    @ExpectedDatabase(value = "classpath:utorak/countryCreate.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void createTest1(){

        Country country = new Country();
        country.setIso3("BRA");
        country.setName("Brazil");
        service.createCountry(country);
    }

    @Test
    @DatabaseSetup("classpath:utorak/countryData.xml")
    void createTest2(){

        Country country = new Country();
        country.setIso3("BRA");
        country.setName("Brazil");
        service.createCountry(country);

        assertEquals("Brazil", service.getCountryById("BRA").getName());

    }







}
