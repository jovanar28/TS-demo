package com.example.demo.vezbe10.utorak;

import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Country;
import com.example.demo.domen.model.Hotel;
import com.example.demo.domen.model.structure.CityStructure;
import com.example.demo.domen.model.structure.CountryStructure;
import com.example.demo.domen.service.CityService;
import com.example.demo.domen.service.CountryService;
import com.example.demo.domen.service.HotelService;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.sql.Time;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DirtiesContext
@TestMethodOrder(MethodOrderer.Random.class)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class HotelTest {

    @Autowired
    private HotelService service;

    @Autowired
    private CityService cityService;

    @Autowired
    private CountryService countryService;

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    void findByIdTest(){
        Hotel hotel=service.getHotelById(11L);

        assertAll(()->assertEquals("name1",hotel.getName()),
                ()->assertEquals("address",hotel.getAddress()));
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    void findByIdTest1(){


        assertThrows(InvalidDataAccessApiUsageException.class, ()->service.getHotelById(null));

    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    void findByIdTest2(){


        assertThrows(NoSuchElementException.class, ()->service.getHotelById(-1L));

    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    void findAll(){
        assertEquals(3,service.getHotels().size());
    }


    @Test
    @DatabaseSetup("classpath:utorak/hotelEmpty.xml")
    void findAll2(){
        assertEquals(0,service.getHotels().size());
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelDelete.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest(){
        service.deleteHotel(11L);
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest1(){
        assertThrows(InvalidDataAccessApiUsageException.class, ()->service.deleteHotel(null));
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteByIdTest2(){
        assertThrows(EmptyResultDataAccessException.class, ()->service.deleteHotel(-1L));
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelEmpty.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void deleteAllTest(){
        service.deleteAllHotels();
    }


    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelCreate.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void createTest(){

        CountryStructure countryStructure = new CountryStructure("SRB", "Serbia");
        Hotel hotel = new Hotel();
        hotel.setName("ime");
        hotel.setAddress("address");
        hotel.setDescription("address33123");
        hotel.setContactPhone("+381 000 000 0000");
        hotel.setCity(new CityStructure(1L,"Belgrade",countryStructure));
        hotel.setCountry(countryStructure);
        hotel.setCheckinTime(Time.valueOf("12:00:00"));
        hotel.setCheckoutTime(Time.valueOf("10:00:00"));

        service.createHotel(hotel);
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void createTest2(){

        assertThrows(NullPointerException.class, ()->service.createHotel(null));
    }


    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelUpdate.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void updateTest(){
        City city = cityService.getCityById(1L);
        Country country = countryService.getCountryById("SRB");
        CountryStructure countryStructure = new CountryStructure(country.getIso3(), country.getName());
        Hotel hotel = new Hotel();
        hotel.setName("ime");
        hotel.setAddress("address");
        hotel.setDescription("address33123");
        hotel.setContactPhone("+381 000 000 0000");
        hotel.setCity(new CityStructure(city.getId(),city.getName(),countryStructure));
        hotel.setCountry(countryStructure);
        hotel.setCheckinTime(Time.valueOf("14:00:00"));
        hotel.setCheckoutTime(Time.valueOf("10:00:00"));

        service.updateHotel(hotel,11L);
    }


    @Disabled
    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void updateTest1(){
        City city = cityService.getCityById(1L);
        Country country = countryService.getCountryById("SRB");
        CountryStructure countryStructure = new CountryStructure(country.getIso3(), country.getName());
        Hotel hotel = new Hotel();
        hotel.setName("ime");
        hotel.setAddress("address");
        hotel.setDescription("address33123");
        hotel.setContactPhone("+381 000 000 0000");
        hotel.setCity(new CityStructure(city.getId(),city.getName(),countryStructure));
        hotel.setCountry(countryStructure);
        hotel.setCheckinTime(Time.valueOf("14:00:00"));
        hotel.setCheckoutTime(Time.valueOf("10:00:00"));

        assertThrows(IllegalArgumentException.class, ()->service.updateHotel(hotel,null));
    }

    @Test
    @DatabaseSetup("classpath:utorak/hotelData.xml")
    @ExpectedDatabase(value = "classpath:utorak/hotelData.xml",
            assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    void updateTest2(){

        assertThrows(NullPointerException.class, ()->service.updateHotel(null,11L));
    }

}
