package com.example.demo.vezbe11.utorak;


import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import netscape.javascript.JSObject;
import org.json.JSONObject;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.NoSuchElementException;
import java.util.stream.Stream;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@DirtiesContext
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class CountryApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CountryService service;

    @Test
    void test() throws Exception {
        when(service.getCountryById("SRB")).thenReturn(getCountry());

        MvcResult result= this.mockMvc.perform(get(getUrl()+"SRB")).andDo(print())
                .andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Serbia")).andReturn();
        JSONObject jsonObject = new JSONObject(result.getResponse().getContentAsString());

        System.out.println(jsonObject.getString("name"));

        System.out.println(jsonObject.getString("iso3"));

    }

    @Test
    void testPost() throws Exception {
        when(service.createCountry(getCountry())).thenReturn(getCountry());

        this.mockMvc.perform(post(createUrl()).contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(getCountry()))).andDo(print()).andExpect(status().isOk());
    }

    public static Stream<Arguments> getSource() {
        return Stream.of(
                Arguments.of(getUrl()+"SRB", status().isOk()),
                Arguments.of(getUrl()+"MNG", status().isNotFound()),
                Arguments.of(getUrl()+"null", status().isBadRequest())
        );
    }

    @ParameterizedTest
    @MethodSource("getSource")
    void testGet(String url, ResultMatcher status) throws Exception {
        when(service.getCountryById("SRB")).thenReturn(getCountry());
        when(service.getCountryById("MNG")).thenThrow(NoSuchElementException.class);
        when(service.getCountryById("null")).thenThrow(IllegalArgumentException.class);

        this.mockMvc.perform(get(url)).andDo(print()).andExpect(status);
    }

    public static Stream<Arguments> deleteSource() {
        return Stream.of(
                Arguments.of(deleteUrl()+"SRB", status().isOk()),
                Arguments.of(deleteUrl()+"MNG", status().isNotFound()),
                Arguments.of(deleteUrl()+"null", status().isBadRequest())
        );
    }

    @ParameterizedTest
    @MethodSource("deleteSource")
    void testDelete(String url, ResultMatcher status) throws Exception {
        doThrow(NoSuchElementException.class).when(service).deleteCountry("MNG");
        doThrow(IllegalArgumentException.class).when(service).deleteCountry("null");


        this.mockMvc.perform(delete(url)).andDo(print()).andExpect(status);
    }


    public static Stream<Arguments> postSource() {
        return Stream.of(
                Arguments.of(createUrl(), getCountry(), status().isOk()),
                Arguments.of(createUrl(), getCountryNoISO3(), status().isBadRequest()),
                Arguments.of(createUrl(), getCountryNoName(), status().isBadRequest()),

                Arguments.of(updateUrl() + "SRB", getCountry(), status().isOk()),
                Arguments.of(updateUrl() + "SRB", getCountryNoName(), status().isBadRequest()),
                Arguments.of(updateUrl() + "SRB", getCountryNoISO3(), status().isBadRequest()),
                Arguments.of(updateUrl() + "MNG", getCountry(), status().isNotFound()),
                Arguments.of(updateUrl() + "null", getCountry(), status().isBadRequest())
                );
    }

    @ParameterizedTest
    @MethodSource("postSource")
    void testPost(String url, Country country, ResultMatcher status) throws Exception {
        when(service.createCountry(getCountry())).thenReturn(getCountry());

        when(service.updateCountry(getCountry(), "SRB")).thenReturn(getCountry());
        when(service.updateCountry(getCountry(), "MNG")).thenThrow(NoSuchElementException.class);
        when(service.updateCountry(getCountry(), "null")).thenThrow(IllegalArgumentException.class);


        this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(asJsonString(country)))
                .andDo(print()).andExpect(status);
    }

    private static Country getCountry(){
        return new Country("SRB", "Serbia");
    }

    private static Country getCountryNoISO3(){
        return new Country("", "Serbia");
    }

    private static Country getCountryNoName(){
        return new Country("SRB", "");
    }

    private static String getUrl(){
        return "/api/country/";
    }

    private static String deleteUrl(){
        return "/api/country/delete/";
    }

    private static String createUrl(){
        return "/api/country/create/";
    }

    private static String updateUrl(){
        return "/api/country/update/";
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
