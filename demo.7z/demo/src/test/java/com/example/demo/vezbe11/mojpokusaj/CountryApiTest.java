package com.example.demo.vezbe11.mojpokusaj;

import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.NoSuchElementException;
import java.util.stream.Stream;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext
@ExtendWith(MockitoExtension.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CountryApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CountryService countryService;

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
             }
        catch (Exception e){
             throw new RuntimeException(e);}
    }

    private static String getUrl(){return ("/api/country/");}

    private static Country getCountry(){return new Country("SRB","Serbia");}

    private static Stream<Arguments> getSource(){
        return Stream.of(
                Arguments.of(getUrl() + "SRB", status().isOk()),
                Arguments.of(getUrl()+"MNG", status().isNotFound()),
                Arguments.of(getUrl()+" ",status().isBadRequest())
        );
    }

    @ParameterizedTest
    @MethodSource("getSource")
    void getTest(String url, ResultMatcher matcher) throws Exception{
        when(countryService.getCountryById("SRB")).thenReturn(getCountry());
        when(countryService.getCountryById("MNG")).thenThrow(NoSuchElementException.class);
        when(countryService.getCountryById(" ")).thenThrow(IllegalArgumentException.class);

        this.mockMvc.perform(get(url)).andDo(print()).andExpect(matcher);
    }


}
