package com.example.demo.vezbe11.utorak;


import com.example.demo.domen.model.Room;
import com.example.demo.domen.model.structure.HotelStructure;
import com.example.demo.domen.service.RoomService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.NoSuchElementException;
import java.util.stream.Stream;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@DirtiesContext
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class RoomApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RoomService service;


    public static Stream<Arguments> getSource() {
        return Stream.of(
                Arguments.of(getUrl() + 1L, status().isOk()),
                Arguments.of(getUrl() + 0L, status().isNotFound()),
                Arguments.of(getUrl() + -1L, status().isBadRequest())
        );
    }

    public static Stream<Arguments> post() {
        return Stream.of(
                Arguments.of(createUrl(), status().isOk(), getRoom()),
                Arguments.of(createUrl(), status().isBadRequest(), getRoomNoName()),
                Arguments.of(createUrl(), status().isBadRequest(), getRoomInvalidNumberOfRooms()),
                Arguments.of(createUrl(), status().isBadRequest(), getRoomInvalidNumberOfPeople()),
                Arguments.of(createUrl(), status().isBadRequest(), getRoomNullHotel()),

                Arguments.of(updateUrl() + 1L, status().isOk(), getRoom()),
                Arguments.of(updateUrl() + 1L, status().isBadRequest(), getRoomNoName()),
                Arguments.of(updateUrl() + 1L, status().isBadRequest(), getRoomInvalidNumberOfRooms()),
                Arguments.of(updateUrl() + 1L, status().isBadRequest(), getRoomInvalidNumberOfPeople()),
                Arguments.of(updateUrl() + 1L, status().isBadRequest(), getRoomNullHotel()),
                Arguments.of(updateUrl() + 0L, status().isNotFound(), getRoom()),
                Arguments.of(updateUrl() + -1L, status().isBadRequest(), getRoom())


        );
    }

    @ParameterizedTest
    @MethodSource("getSource")
    void testGet(String url, ResultMatcher status) throws Exception {
        when(service.getRoomById(1L)).thenReturn(getRoom());
        when(service.getRoomById(0L)).thenThrow(NoSuchElementException.class);
        when(service.getRoomById(-1L)).thenThrow(IllegalArgumentException.class);

        this.mockMvc.perform(get(url)).andDo(print()).andExpect(status);
    }

    public static Stream<Arguments> deleteSource() {
        return Stream.of(
                Arguments.of(deleteUrl() + 1L, status().isOk()),
                Arguments.of(deleteUrl() + 0L, status().isNotFound()),
                Arguments.of(deleteUrl() + -1L, status().isBadRequest())
        );
    }

    @ParameterizedTest
    @MethodSource("deleteSource")
    void testDelete(String url, ResultMatcher status) throws Exception {
        doThrow(NoSuchElementException.class).when(service).deleteRoom(0L);
        doThrow(IllegalArgumentException.class).when(service).deleteRoom(-1L);

        this.mockMvc.perform(delete(url)).andDo(print()).andExpect(status);
    }

    private static Room getRoom() {
        return new Room(1L, "name", 2, 4, new HotelStructure());
    }



    @ParameterizedTest
    @MethodSource("post")
    void postTest(String url, ResultMatcher status, Room room) throws Exception {
        when(service.updateRoom(getRoom(), 0L)).thenThrow(NoSuchElementException.class);
        when(service.updateRoom(getRoom(), -1L)).thenThrow(IllegalArgumentException.class);

        this.mockMvc.perform(
                MockMvcRequestBuilders.post(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(room))
        ).andDo(print()).andExpect(status);
    }

    private static Room getRoomNoName() {
        return new Room(1L, "", 2, 4, new HotelStructure());
    }

    private static Room getRoomInvalidNumberOfRooms() {
        return new Room(1L, "name", 0, 4, new HotelStructure());
    }

    private static Room getRoomInvalidNumberOfPeople() {
        return new Room(1L, "name", 2, -1, new HotelStructure());
    }

    private static Room getRoomNullHotel() {
        return new Room(1L, "name", 2, 4, null);
    }

    private static String getUrl() {
        return "/api/room/";
    }

    private static String deleteUrl() {
        return "/api/room/delete/";
    }

    private static String createUrl() {
        return "/api/room/create/";
    }

    private static String updateUrl() {
        return "/api/room/update/";
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


}
