package com.example.demo.domen.service;

import com.example.demo.domen.model.Hotel;

import java.util.List;

public interface HotelService {
    Hotel getHotelById(Long id);

    List<Hotel> getHotels();

    void deleteHotel(Long id);

    void deleteAllHotels();

    Hotel createHotel(Hotel hotel);

    Hotel updateHotel(Hotel hotel, Long id);
}
