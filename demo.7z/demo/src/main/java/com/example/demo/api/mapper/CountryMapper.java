package com.example.demo.api.mapper;

import com.example.demo.api.dto.CityDTO;
import com.example.demo.api.dto.CountryDTO;
import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Country;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CountryMapper {

    Country countryDTOToCountry(CountryDTO countryDTO);

    CountryDTO countryToCountryDTO(Country country);


}
