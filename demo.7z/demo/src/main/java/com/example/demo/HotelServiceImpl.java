package com.example.demo;

import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Country;
import com.example.demo.domen.model.Hotel;
import com.example.demo.domen.service.CityService;
import com.example.demo.domen.service.CountryService;
import com.example.demo.domen.service.HotelService;
import com.example.demo.persistence.entity.CityEntity;
import com.example.demo.persistence.entity.HotelEntity;
import com.example.demo.persistence.mapper.CityServiceMapper;
import com.example.demo.persistence.mapper.CountryServiceMapper;
import com.example.demo.persistence.mapper.HotelServiceMapper;
import com.example.demo.persistence.repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelServiceImpl implements HotelService {

    private HotelRepository repository;

    private HotelServiceMapper mapper;

    private CityService cityService;

    private CityServiceMapper cityMapper;
    private CountryService countryService;

    private CountryServiceMapper countryMapper;


    @Autowired
    public HotelServiceImpl(HotelRepository repository, HotelServiceMapper mapper,
                            CityService cityService, CountryService countryService,
                            CountryServiceMapper countryMapper, CityServiceMapper cityMapper) {
        this.repository = repository;
        this.mapper = mapper;
        this.cityService = cityService;
        this.countryService = countryService;
        this.countryMapper = countryMapper;
        this.cityMapper = cityMapper;
    }

    @Override
    public Hotel getHotelById(Long id) {
        HotelEntity entity = repository.findById(id).orElseThrow();

        return mapper.hotelEntityToHotel(entity);
    }

    @Override
    public List<Hotel> getHotels() {
        List<HotelEntity> entities = (List<HotelEntity>) repository.findAll();

        return mapper.hotelEntityListToHotelList(entities);
    }

    @Override
    public void deleteHotel(Long id) {
        repository.deleteById(id);
    }

    @Override
    public void deleteAllHotels() {
        repository.deleteAll();
    }

    @Override
    public Hotel createHotel(Hotel hotel) {
        HotelEntity entity = mapper.hotelToHotelEntity(hotel);
        City city = cityService.getCityById(hotel.getCity().getId());
        Country country = countryService.getCountryById(hotel.getCountry().getIso3());
        entity.setCity(cityMapper.cityToCityEntity(city));
        entity.setCountry(countryMapper.countryToCountryEntity(country));
        entity = repository.save(entity);
        return mapper.hotelEntityToHotel(entity);
    }

    @Override
    public Hotel updateHotel(Hotel hotel, Long id) {
        HotelEntity entity = mapper.hotelToHotelEntity(hotel);
        entity.setId(id);
        City city = cityService.getCityById(hotel.getCity().getId());
        Country country = countryService.getCountryById(hotel.getCountry().getIso3());
        entity.setCity(cityMapper.cityToCityEntity(city));
        entity.setCountry(countryMapper.countryToCountryEntity(country));
        entity = repository.save(entity);
        return mapper.hotelEntityToHotel(entity);
    }
}
