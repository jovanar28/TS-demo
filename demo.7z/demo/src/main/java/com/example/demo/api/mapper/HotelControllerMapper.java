package com.example.demo.api.mapper;

import com.example.demo.api.dto.HotelDTO;
import com.example.demo.domen.model.Hotel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface HotelControllerMapper {

    Hotel hotelDTOToHotel(HotelDTO hotelDTO);

    List<HotelDTO> hotelListToHotelDTOList(List<Hotel> hotels);


    HotelDTO hotelToHotelDTO(Hotel hotel);


}
