package com.example.demo.api.controller;

import com.example.demo.api.dto.RoomDTO;
import com.example.demo.api.mapper.RoomControllerMapper;
import com.example.demo.domen.model.Room;
import com.example.demo.domen.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(path = "/api/room")
public class RoomController {

    private final RoomService service;

    private final RoomControllerMapper mapper;

    @Autowired
    public RoomController(RoomService service, RoomControllerMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @GetMapping(path = "/{id}")
    public RoomDTO getRoom(@PathVariable final long id) {
        Room studio = service.getRoomById(id);
        return mapper.roomToRoomDTO(studio);
    }

    @GetMapping(path = "/all")
    public List<RoomDTO> getStudios() {
        List<Room> studios = service.getRooms();

        return mapper.roomListToRoomsDTOList(studios);
    }

    @PostMapping(path = "/create")
    public RoomDTO createAmenity(@RequestBody @Valid final RoomDTO roomDTO) {

        Room room = mapper.roomDTOToRoom(roomDTO);
        Room response = service.createRoom(room);
        return mapper.roomToRoomDTO(response);
    }

    @DeleteMapping(path = "/delete/{id}")
    public void deleteAmenity(@PathVariable final Long id) {
        service.deleteRoom(id);
    }

    @DeleteMapping(path = "/delete/all")
    public void deleteAllAmenities() {
        service.deleteAllRooms();
    }

    @PostMapping(path = "/update/{id}")
    public RoomDTO updateAmenity(@RequestBody @Valid final RoomDTO roomDTO, @PathVariable final long id) {
        Room room = mapper.roomDTOToRoom(roomDTO);
        Room response = service.updateRoom(room, id);
        return mapper.roomToRoomDTO(response);
    }
}
