package com.example.demo.domen.service;

import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Country;
import com.example.demo.domen.model.Hotel;

import java.util.List;

public interface CountryService {
    void deleteAll();
    Country getCountryById(String iso3);

    void deleteCountry(String iso3);

    Country createCountry(Country country);

    Country updateCountry(Country country, String iso3);
}
