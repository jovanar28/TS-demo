package com.example.demo.api.controller;

import com.example.demo.api.dto.CountryDTO;
import com.example.demo.api.mapper.CountryMapper;
import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(path = "/api/country")
public class CountryController {


    private final CountryService service;

    private final CountryMapper mapper;

    public CountryController(CountryService countryService, CountryMapper countryMapper) {
        this.service = countryService;
        this.mapper = countryMapper;
    }

    @GetMapping(path = "/{iso3}")
    public CountryDTO getCountry(@PathVariable final String iso3) {
        Country response = service.getCountryById(iso3);
        return mapper.countryToCountryDTO(response);
    }


    @DeleteMapping(path = "/delete/{iso3}")
    public void deleteCountry(@PathVariable final String iso3) {
        service.deleteCountry(iso3);
    }

    @DeleteMapping(path = "/delete/all")
    public void deleteAllFacilities() {
        service.deleteAll();
    }

    @PostMapping(path = "/create")
    public CountryDTO createCountry(@RequestBody @Valid final CountryDTO countryDTO) {
        Country country = mapper.countryDTOToCountry(countryDTO);
        country = service.createCountry(country);
        return mapper.countryToCountryDTO(country);
    }

    @PostMapping(path = "/update/{iso3}")
    public CountryDTO updateCountry(@RequestBody @Valid final CountryDTO countryDTO,
                                    @PathVariable final String iso3) {
        Country country = mapper.countryDTOToCountry(countryDTO);
        country = service.updateCountry(country, iso3);
        return mapper.countryToCountryDTO(country);
    }

}
