package com.example.demo.api.controller;

import com.example.demo.api.dto.HotelDTO;
import com.example.demo.api.mapper.HotelControllerMapper;
import com.example.demo.domen.model.Hotel;
import com.example.demo.domen.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/hotel")
public class HotelController {

    private HotelService service;

    private HotelControllerMapper mapper;

    @Autowired
    public HotelController(HotelService service, HotelControllerMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @GetMapping(path = "/{id}")
    public HotelDTO getFacility(@PathVariable final Long id) {
        Hotel response = service.getHotelById(id);
        return mapper.hotelToHotelDTO(response);
    }

    @GetMapping(path = "/all")
    public List<HotelDTO> getFacilities() {
        List<Hotel> serviceFacilityResponses = service.getHotels();

        return mapper.hotelListToHotelDTOList(serviceFacilityResponses);
    }

    @DeleteMapping(path =  "/delete/{id}")
    public void deleteFacility(@PathVariable final Long id) {
        service.deleteHotel(id);
    }

    @DeleteMapping(path = "/delete/all")
    public void deleteAllFacilities() {
        service.deleteAllHotels();
    }

    @PostMapping(path = "/create")
    public HotelDTO createFacility(@RequestBody final HotelDTO hotelDTO) {
        Hotel hotel = mapper.hotelDTOToHotel(hotelDTO);
        hotel = service.createHotel(hotel);
        return mapper.hotelToHotelDTO(hotel);
    }

    @PostMapping(path = "/update/{id}")
    public HotelDTO updateFacility(@RequestBody final HotelDTO hotelDTO,
                                             @PathVariable final Long id) {
        Hotel hotel = mapper.hotelDTOToHotel(hotelDTO);
        hotel = service.updateHotel(hotel,id);
        return mapper.hotelToHotelDTO(hotel);
    }

}
