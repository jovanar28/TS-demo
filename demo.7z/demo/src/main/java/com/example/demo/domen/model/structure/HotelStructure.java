package com.example.demo.domen.model.structure;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Time;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class HotelStructure {

    private Long id;

    private String address;
    private String name;
    private String contactPhone;

    private String description;

    private Time checkinTime;

    private Time checkoutTime;


}
