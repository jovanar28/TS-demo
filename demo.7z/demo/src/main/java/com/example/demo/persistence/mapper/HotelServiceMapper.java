package com.example.demo.persistence.mapper;

import com.example.demo.domen.model.Hotel;
import com.example.demo.persistence.entity.HotelEntity;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface HotelServiceMapper {


    Hotel hotelEntityToHotel(HotelEntity entity);

    List<Hotel> hotelEntityListToHotelList(
            List<HotelEntity> entities);

    HotelEntity hotelToHotelEntity(Hotel hotel);
}
