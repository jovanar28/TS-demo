package com.example.demo.persistence.mapper;

import com.example.demo.domen.model.Country;
import com.example.demo.persistence.entity.CountryEntity;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CountryServiceMapper {

    Country countryEntityToCountry(CountryEntity entity);

    Country map(CountryEntity entity);

    CountryEntity countryToCountryEntity(Country country);
}
