package com.example.demo.domen.service;

import com.example.demo.domen.model.Room;

import java.util.List;

public interface RoomService {
    Room getRoomById(Long id);

    List<Room> getRooms();

    Room createRoom(Room room);

    void deleteRoom(Long id);

    void deleteAllRooms();

    Room updateRoom(Room room, Long id);
}
