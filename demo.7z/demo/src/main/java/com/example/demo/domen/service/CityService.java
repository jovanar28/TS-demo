package com.example.demo.domen.service;

import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Hotel;

import java.util.List;

public interface CityService {
    void deleteAll();

    City getCityById(Long id);

    void deleteCity(Long id);

    City createCity(City city);

    City updateCity(City city, Long id);

}
