package com.example.demo;

import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CityService;
import com.example.demo.domen.service.CountryService;
import com.example.demo.persistence.entity.CityEntity;
import com.example.demo.persistence.mapper.CityServiceMapper;
import com.example.demo.persistence.mapper.CountryServiceMapper;
import com.example.demo.persistence.repository.CityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CityServiceImpl implements CityService {

    private final CityRepository cityRepository;

    private final CountryService countryService;

    private final CityServiceMapper mapper;

    private final CountryServiceMapper countryMapper;


    @Autowired
    public CityServiceImpl(CityRepository cityRepository, CityServiceMapper mapper,
                            CountryService countryService, CountryServiceMapper countryMapper) {
        this.cityRepository = cityRepository;
        this.countryService = countryService;
        this.mapper = mapper;
        this.countryMapper = countryMapper;
    }

    @Override
    public void deleteAll() {
        cityRepository.deleteAll();
    }

    @Override
    public City getCityById(final Long id) {
        CityEntity entity = cityRepository.findById(id).orElseThrow();

        return mapper.cityEntityToCity(entity);
    }


    @Override
    public void deleteCity(Long id) {
        cityRepository.deleteById(id);
    }

    @Override
    public City createCity(City city) {
        Country country = countryService.getCountryById(city.getCountry().getIso3());
        CityEntity entity = mapper.cityToCityEntity(city);
        entity.setCountry(countryMapper.countryToCountryEntity(country));
        entity = cityRepository.save(entity);
        return mapper.cityEntityToCity(entity);
    }

    @Override
    public City updateCity(City city, Long id) {
        Country country = countryService.getCountryById(city.getCountry().getIso3());
        CityEntity entity = mapper.cityToCityEntity(city);
        entity.setCountry(countryMapper.countryToCountryEntity(country));
        entity.setId(id);
        entity = cityRepository.save(entity);
        return mapper.cityEntityToCity(entity);
    }


}
