package com.example.demo;

import com.example.demo.domen.model.Hotel;
import com.example.demo.domen.model.Room;
import com.example.demo.domen.service.HotelService;
import com.example.demo.domen.service.RoomService;
import com.example.demo.persistence.entity.HotelEntity;
import com.example.demo.persistence.entity.RoomEntity;
import com.example.demo.persistence.mapper.HotelServiceMapper;
import com.example.demo.persistence.mapper.RoomServiceMapper;
import com.example.demo.persistence.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    private RoomRepository repository;

    private RoomServiceMapper mapper;

    private HotelService hotelService;

    private HotelServiceMapper hotelMapper;

    @Autowired
    public RoomServiceImpl(RoomRepository repository, RoomServiceMapper mapper, HotelService hotelService,
                           HotelServiceMapper hotelMapper) {
        this.repository = repository;
        this.mapper = mapper;
        this.hotelService = hotelService;
        this.hotelMapper = hotelMapper;
    }

    @Override
    public Room getRoomById(Long id) {
        RoomEntity entity = repository.findById(id).orElseThrow();

        return mapper.roomEntityToRoom(entity);
    }

    @Override
    public List<Room> getRooms() {
        List<RoomEntity> entities = (List<RoomEntity>) repository.findAll();

        return mapper.roomEntityListToRoomList(entities);
    }

    @Override
    public Room createRoom(Room room) {
        RoomEntity entity = mapper.roomToRoomEntity(room);
        Hotel hotel = hotelService.getHotelById(entity.getHotel().getId());
        entity.setHotel(hotelMapper.hotelToHotelEntity(hotel));
        entity = repository.save(entity);
        return mapper.roomEntityToRoom(entity);
    }

    @Override
    public void deleteRoom(Long id) {
        repository.findById(id);
    }

    @Override
    public void deleteAllRooms() {
        repository.deleteAll();
    }

    @Override
    public Room updateRoom(Room room, Long id) {
        RoomEntity entity = mapper.roomToRoomEntity(room);
        entity.setId(id);
        Hotel hotel = hotelService.getHotelById(entity.getHotel().getId());
        entity.setHotel(hotelMapper.hotelToHotelEntity(hotel));
        entity = repository.save(entity);
        return mapper.roomEntityToRoom(entity);
    }
}
