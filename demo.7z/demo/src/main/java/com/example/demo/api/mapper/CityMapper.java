package com.example.demo.api.mapper;

import com.example.demo.api.dto.CityDTO;
import com.example.demo.api.dto.HotelDTO;
import com.example.demo.domen.model.City;
import com.example.demo.domen.model.Hotel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CityMapper {

    City cityDTOToCity(CityDTO cityDTO);

    CityDTO cityToCityDTO(City city);


}
