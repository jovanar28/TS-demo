package com.example.demo.api.controller;

import com.example.demo.api.dto.ErrorDTO;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;

@RestControllerAdvice
public class ExceptionHandlerAdvice {

    private static String getTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss dd-MM-yyyy"));
    }


    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoSuchElementException.class)
    public ErrorDTO handleMethodArgumentNotValidException(final NoSuchElementException exception) {
        ErrorDTO errorDTO = new ErrorDTO(exception.getMessage(), getTime());

        return errorDTO;
    }

//    @ResponseStatus(HttpStatus.NOT_FOUND)
//    @ExceptionHandler(NoSuchElementException.class)
//    public Map<String,String> handleNoSuchElementException(final NoSuchElementException exception) {
//        Map<String,String> map = new HashMap<>();
//
//        map.put("Error", exception.getMessage());
//        return map;
//    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ErrorDTO handleHttpMessageNotReadableException(final MethodArgumentNotValidException exception) {
        ErrorDTO errorDTO = new ErrorDTO(exception.getMessage(), getTime());

        return errorDTO;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(IllegalArgumentException.class)
    public ErrorDTO handleIllegalArgumentException(final IllegalArgumentException exception) {
        ErrorDTO errorDTO = new ErrorDTO(exception.getMessage(), getTime());

        return errorDTO;
    }
}
