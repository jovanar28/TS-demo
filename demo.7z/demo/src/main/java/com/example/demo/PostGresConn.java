package com.example.demo;

    import java.sql.*;

    public class PostGresConn {
        public static void main(String[] args) {
            Connection conn = null;
            try {
                // Register the driver
                Class.forName("org.postgresql.Driver");

                // Set the connection parameters
                String url = "jdbc:postgresql://localhost:5432/test";
                String user = "postgres";
                String password = "password";

                // Connect to the database
                conn = DriverManager.getConnection(url, user, password);

                // Print out the connection status
                System.out.println("Successfully connected to the database!");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                // Close the connection
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


