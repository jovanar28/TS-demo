package com.example.demo.persistence.mapper;

import com.example.demo.domen.model.Room;
import com.example.demo.persistence.entity.RoomEntity;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface RoomServiceMapper {

    Room roomEntityToRoom(RoomEntity entity);

    List<Room> roomEntityListToRoomList(List<RoomEntity> entities);

    RoomEntity roomToRoomEntity(Room room);

}
