package com.example.demo.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ErrorDTO {

    private String message;

    private String time;

    @Override
    public String toString() {
        return "ErrorDTO{"
                + ", message='" + message + '\''
                + ", time='" + time + '\'' + '}';
    }
}
