package com.example.demo.domen.model;

import com.example.demo.domen.model.structure.CityStructure;
import com.example.demo.domen.model.structure.CountryStructure;
import com.example.demo.persistence.entity.CityEntity;
import com.example.demo.persistence.entity.CountryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Time;


@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class Hotel {


    private Long id;

    private String address;
    private String name;
    private String contactPhone;

    private String description;

    private Time checkinTime;

    private Time checkoutTime;

    private CityStructure city;

    private CountryStructure country;

}
