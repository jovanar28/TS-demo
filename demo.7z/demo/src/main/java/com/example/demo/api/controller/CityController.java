package com.example.demo.api.controller;

import com.example.demo.api.dto.CityDTO;
import com.example.demo.api.mapper.CityMapper;
import com.example.demo.domen.model.City;
import com.example.demo.domen.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/city")
public class CityController {


    private final CityService service;

    private final CityMapper mapper;

    @Autowired
    public CityController(CityService service, CityMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @GetMapping(path = "/{id}")
    public CityDTO getCountry(@PathVariable final Long id) {
        City response = service.getCityById(id);
        return mapper.cityToCityDTO(response);
    }


    @DeleteMapping(path = "/delete/{id}")
    public void deleteCountry(@PathVariable final Long id) {
        service.deleteCity(id);
    }

    @DeleteMapping(path = "/delete/all")
    public void deleteAllFacilities() {
        service.deleteAll();
    }

    @PostMapping(path = "/create")
    public CityDTO createCountry(@RequestBody final CityDTO cityDTO) {
        City city = mapper.cityDTOToCity(cityDTO);
        city = service.createCity(city);
        return mapper.cityToCityDTO(city);
    }

    @PostMapping(path = "/update/{id}")
    public CityDTO updateCountry(@RequestBody final CityDTO cityDTO,
                                 @PathVariable final Long id) {
        City city = mapper.cityDTOToCity(cityDTO);
        city = service.updateCity(city, id);
        return mapper.cityToCityDTO(city);
    }

}
