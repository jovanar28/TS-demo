package com.example.demo.api.mapper;

import com.example.demo.api.dto.RoomDTO;
import com.example.demo.domen.model.Room;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface RoomControllerMapper {

    Room roomDTOToRoom(RoomDTO roomDTO);


    RoomDTO roomToRoomDTO(Room room);

    List<RoomDTO> roomListToRoomsDTOList(List<Room> rooms);


}
