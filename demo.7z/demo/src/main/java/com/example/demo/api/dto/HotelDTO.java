package com.example.demo.api.dto;

import com.example.demo.api.dto.structure.CityStructure;
import com.example.demo.api.dto.structure.CountryStructure;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Time;


@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class HotelDTO {

    private Long id;

    private String address;
    private String name;
    private String contactPhone;

    private String description;

    private Time checkinTime;

    private Time checkoutTime;

    private CityStructure city;

    private CountryStructure country;

}
