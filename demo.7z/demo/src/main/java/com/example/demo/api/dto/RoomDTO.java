package com.example.demo.api.dto;

import com.example.demo.api.dto.structure.HotelStructure;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoomDTO {

    private Long id;
    @NotBlank
    private String name;
    @Min(1)
    private Integer numberOfRooms;
    @Min(1)
    private Integer numberOfPeople;
    @NotNull
    private HotelStructure hotel;


}
