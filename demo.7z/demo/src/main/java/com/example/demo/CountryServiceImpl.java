package com.example.demo;

import com.example.demo.domen.model.Country;
import com.example.demo.domen.service.CountryService;
import com.example.demo.persistence.entity.CityEntity;
import com.example.demo.persistence.entity.CountryEntity;
import com.example.demo.persistence.mapper.CountryServiceMapper;
import com.example.demo.persistence.repository.CountryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;

    private final CountryServiceMapper mapper;

    @Autowired
    public CountryServiceImpl(final CountryRepository countryRepository, final CountryServiceMapper mapper) {
        this.countryRepository = countryRepository;
        this.mapper = mapper;
    }

    @Override
    public void deleteAll() {
        countryRepository.deleteAll();
    }

    @Override
    public Country getCountryById(final String iso3) {
        CountryEntity entity = countryRepository.findById(iso3).orElseThrow();

        return mapper.countryEntityToCountry(entity);
    }

    @Override
    public void deleteCountry(String iso3) {
        countryRepository.deleteById(iso3);
    }

    @Override
    public Country createCountry(Country country) {
        CountryEntity entity = mapper.countryToCountryEntity(country);
        entity = countryRepository.save(entity);
        return mapper.countryEntityToCountry(entity);
    }

    @Override
    public Country updateCountry(Country country, String iso3) {
        CountryEntity entity = mapper.countryToCountryEntity(country);
        entity.setIso3(iso3);
        entity = countryRepository.save(entity);
        return mapper.countryEntityToCountry(entity);
    }


}
