package com.example.demo.persistence.mapper;

import com.example.demo.domen.model.City;
import com.example.demo.persistence.entity.CityEntity;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CityServiceMapper {

    City cityEntityToCity(CityEntity entity);

    CityEntity cityToCityEntity(City city);
}
