package com.example.demo.persistence.repository;

import com.example.demo.persistence.entity.HotelEntity;
import org.springframework.data.repository.CrudRepository;

public interface HotelRepository extends CrudRepository<HotelEntity, Long> {
}
